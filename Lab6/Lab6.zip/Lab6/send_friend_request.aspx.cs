﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace Lab6
{
    public partial class send_friend_request : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string senderr = null;
            if (Session["LoggedInUser"] != null)
            {
                senderr = (string)Session["LoggedInUser"];
            } 
            string receiverr = null;
            if (Session["FriendEmail"] != null)
            {
                receiverr = (string)Session["FriendEmail"];
            }
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            SqlCommand view = new SqlCommand("send_req", conn);
            view.CommandType = CommandType.StoredProcedure;

            view.Parameters.Add(new SqlParameter("@sender", senderr));
            view.Parameters.Add(new SqlParameter("@receiver", receiverr));

            conn.Open();
            SqlDataReader rdr = view.ExecuteReader(CommandBehavior.CloseConnection);

            Response.Redirect("~\view_friend_profile.aspx");

        }
    }
}