﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace Lab6
{
    public partial class view_friend_profile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string viewer = null;
            if (Session["LoggedInUser"] != null)
            {
                viewer = (string)Session["LoggedInUser"];
            } 
           string email = null;
           if(Session["FriendEmail"]!=null){
               email = (string) Session["FriendEmail"];
           }
           string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
           SqlConnection conn = new SqlConnection(connStr);

           SqlCommand view = new SqlCommand("view_profile", conn);
           view.CommandType = CommandType.StoredProcedure;

           view.Parameters.Add(new SqlParameter("@email1", viewer));
           view.Parameters.Add(new SqlParameter("@email2", email));

           conn.Open();
           SqlDataReader rdr = view.ExecuteReader(CommandBehavior.CloseConnection);
           rdr.Read();

           string Email = rdr.GetString(rdr.GetOrdinal("email"));
           string FirstName = rdr.GetString(rdr.GetOrdinal("fname"));
           string LastName = rdr.GetString(rdr.GetOrdinal("lname"));
           string address = rdr.GetString(rdr.GetOrdinal("addres"));
           string nationality = rdr.GetString(rdr.GetOrdinal("nationality"));

           Label lbl_users = new Label();
           lbl_users.Text = "First name: " + FirstName + "<br />" + "Last name: " + LastName + "<br />" + "Email: " + Email + "<br />" + "Address: " + address + "<br />" + "Nationality: " + nationality;
           form1.Controls.Add(lbl_users);
       }
    }
}